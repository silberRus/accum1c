package service

import "inventory/internal/repository"

type Service struct {
	repo *repository.Repository
}

type UpdateInventoryRequest struct {
	ProductID string `json:"product_id"`
	Delta     int    `json:"delta"`
}

func NewService(repo *repository.Repository) *Service {
	return &Service{repo: repo}
}

func (s *Service) UpdateInventory(request UpdateInventoryRequest) error {
	return s.repo.UpdateInventoryInRedis(request.ProductID, "quantity", request.Delta)
}

func (s *Service) GetInventory(productID string) (int, error) {
	return s.repo.GetInventoryFromRedis(productID, "quantity")
}
